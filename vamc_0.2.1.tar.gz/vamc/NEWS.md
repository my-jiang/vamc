# vamc News

### v0.2.1 2020-02-26
- Fixed minor typos in the documentations

### v0.2.0 2020-02-03
- Added option bdc = "Actual" in _buildCurve()_
- Added new feature to _buildCurve()_ to support user-defined calendar

### v0.1.1 2020-01-20
- _genPortIndex()_ tests and examples only run under supporting-long-double platforms to avoid additional noLD issues

### v0.1.0 2018-10-08
- First release