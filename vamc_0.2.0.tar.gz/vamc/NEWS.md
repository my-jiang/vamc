# vamc News

### v0.2.0
- Added option bdc = "Actual" in _buildCurve()_
- Added new feature to _buildCurve()_ to support user-defined calendar

### v0.1.1
- genPortIndex() tests and examples only run under supporting-long-double platforms to avoid additional noLD issues

### v0.1.0
- First release