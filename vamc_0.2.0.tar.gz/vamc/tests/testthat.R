library(testthat)
library(vamc)

test_check("vamc")

